import random
import unittest
from db import Database
import mysql.connector
from mysql.connector import Error

class TestDatabase(unittest.TestCase):
    """
    Test for adding, updating, fetching, and deleting books
    """
    @classmethod
    def setUpClass(self):
        """
        Initializes database connection
        """
        self.db = Database()

    @classmethod
    def tearDownClass(self):
        """
        closes database
        """
        del self.db
    
    def get_isbn(self):
        """Generates a random 13 digit ISBN

        Returns:
            str: 13 digit ISBN
        """
        return ''.join([str(random.randint(0,9)) for i in range(13)])


    def test_add_book(self):
        """
        Testing for adding a book and checks ISBN to see reults
        """
        isbn = self.get_isbn()
        self.db.insert_book("The Yoda", "Mir Ahmed", isbn, 10, 10, 9.95 )
        
        results = self.db.fetch_books()
        self.assertTrue(any(book['isbn'] == isbn for book in results))



    def test_single_book(self):
        """
        Fetches single book and verifies book
        """
        isbn = self.get_isbn()
        self.db.insert_book("Single Book", "Single Author", isbn, 6, 3, 2.98)
        results = self.db.fetch_books()
        book_id = next(book['id'] for book in results if book['isbn'] == isbn)

        fetch_book = self.db.fetch_books(book_id=book_id)
        self.assertEqual(fetch_book['title'], "Single Book")
        self.assertEqual(fetch_book['author'], "Single Author")
        self.assertEqual(fetch_book['isbn'], isbn)

    def test_update_book(self):
        """
        Test for updating book info and changing. Checks to verify if changes occured
        """
        isbn = self.get_isbn()
        self.db.insert_book("Test Book", "Test Author", isbn, 5, 5, 10.95)
        results = self.db.fetch_books()
        book_id = next(book['id'] for book in results if book['isbn'] == isbn)
        self.db.update_book(book_id, "Updated Test Book", "Updated Author", isbn, 6, 6, 20.95 )
        
        updated_book = self.db.fetch_books(book_id=book_id)
        
        self.assertEqual(updated_book['title'], "Updated Test Book")
        self.assertEqual(updated_book['author'], "Updated Author")
        self.assertEqual(updated_book['copies_purchased'], 6)
        self.assertEqual(updated_book['copies_available'], 6)
        self.assertEqual(float(updated_book['retail_price']), 20.95)


    def test_delete_book(self):
        """
        Deletes book and verifies if it happend
        """
        isbn = self.get_isbn()
        self.db.insert_book("Delete Book", "Delete Author", isbn, 8, 8, 30.95)
        
        results = self.db.fetch_books()
        book_id = next(book['id'] for book in results if book['isbn'] == isbn)
        self.db.remove_book(book_id)
        results = self.db.fetch_books()
        self.assertFalse(any(book['id'] == book_id for book in results))

if __name__ == '__main__':
    unittest.main()