import mysql.connector
from mysql.connector import Error

class Database:
    """
    Class for the database that could add, update, and delete
    """
    def __init__(self):
        """
        Connects to MySQL
        """
        self.conn = None
        try: #creates MySQL connection to database
            self.conn = mysql.connector.connect(
                host = 'localhost',
                user = 'root',
                password = '',
                database = 'book_gui'
            )
            if self.conn.is_connected():
                print("Connected to MYSQL database")
        except Error as e:
            print(f"Error connecting to database: {e}")
            self.conn = None

    def fetch_books(self, book_id=None):
        """Fetches books by ID

        Args:
            book_id (int): ID of the book

        Returns:
            list and dict: list of every book or dict of one book and info
        """
        try: #gets book by id
            cursor = self.conn.cursor(dictionary=True)
            if book_id:
                cursor.execute("SELECT * FROM books WHERE id = %s", (book_id,))
                return cursor.fetchone()
            else: #fetch all books
                cursor.execute("SELECT * FROM books")
                return cursor.fetchall() #all rows
        except Error as e:
            print(f"Error fetching: {e}")
            return None
        finally:
            cursor.close() #close fetching data

    def insert_book(self, title, author, isbn, copies_purchased, copies_available, retail_price):
        """Inserrts book in database

        Args:
            title (str)
            author (str)
            isbn (bool)
            copies_purchased (int)
            copies_available (int)
            retail_price (float)
        """
        try:
            cursor = self.conn.cursor() #book detail inserted
            cursor.execute(
                "INSERT INTO books (title, author, isbn, copies_purchased, copies_available, retail_price) "
                "VALUES (%s, %s, %s, %s, %s, %s)",
                (title, author, isbn, copies_purchased, copies_available, retail_price)
            )
            self.conn.commit() #save changes
        except Error as e:
            print(f"Error inserting book: {e}")
        finally:
            cursor.close()

    def update_book(self, book_id, title, author, isbn, copies_purchased, copies_available, retail_price):
        """_summary_

        Args:
            book_id (str)
            title (str)
            author (_str)
            isbn (bool)
            copies_purchased (int)
            copies_available (int)
            retail_price (float)
        """
        try:
            cursor = self.conn.cursor() #update book information 
            print(f"Updating book with ID: {book_id}")

            cursor.execute(
                "UPDATE books SET title=%s, author=%s, isbn=%s, copies_purchased=%s, copies_available=%s, retail_price=%s "
                "WHERE id=%s",
                (title, author, isbn, copies_purchased, copies_available, retail_price, book_id)
            )
            self.conn.commit() #save changes
        except Error as e:
            print(f"Error updating books: {e}")
        finally:
            cursor.close()

    def remove_book(self, book_id):
        """removes book by ID

        Args:
            book_id (int): ID of the removed book 
        """
        try: #delete book from the table
            cursor = self.conn.cursor()
            print(f"Deleting book with ID: {book_id}")


            cursor.execute("DELETE FROM books WHERE id=%s", (book_id,))
            self.conn.commit() #confirms delete
        except Error as e:
            print(f"Error removing book: {e}")
        finally:
            cursor.close()
            
    def __del__(self):
        """Closes MySQL connection
        """
        if self.conn and self.conn.is_connected():
            self.conn.close()
            print("MySQL connection closed")