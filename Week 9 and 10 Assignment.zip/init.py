import mysql.connector 
from mysql.connector import Error

def create_database_and_table():
    """Creates database and table 
    """
    conn = None
    cursor = None
    try:
        conn = mysql.connector.connect( #connection to MySQL
            host = 'localhost',
            user = 'root',
            password = ''
        )
        if conn.is_connected():
            cursor = conn.cursor()
            cursor.execute("CREATE DATABASE IF NOT EXISTS book_gui")
            print("Database 'book_gui' created or already exists.")

            cursor.execute("USE book_gui")

            #creates book table 
            create_table_query = ''' 
            CREATE TABLE IF NOT EXISTS books (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                author VARCHAR(255) NOT NULL,
                isbn VARCHAR(13) NOT NULL UNIQUE,
                copies_purchased INT NOT NULL,
                copies_available INT NOT NULL,
                retail_price DECIMAL(10,2)
            );
            '''
            cursor.execute(create_table_query)
            print("Table 'books' created or already exists.")
            conn.commit()
    except Error as e:
        print(f"Error: {e}")

    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()
            print("MYSQL connection is closed")

if __name__ == "__main__":
    create_database_and_table()