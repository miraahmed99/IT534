import tkinter as tk
from tkinter import messagebox
from db import Database
from Validation import Validator
import ast

db = Database()

class LibraryApp:
    """Handles GUI for the library 
    """
    def __init__(self, root):
        """Creates the window and widgets

        Args:
            root: Root window
        """
        self.root = root
        self.db = Database() #connects to database
        self.root.title("Library System")

        self.title_entry = tk.Entry(root)
        self.author_entry = tk.Entry(root)
        self.isbn_entry = tk.Entry(root)
        self.copies_purchased_entry = tk.Entry(root)
        self.copies_available_entry = tk.Entry(root)
        self.price_entry = tk.Entry(root)

        #Labels for all the fields on the grid
        tk.Label(root, text="Title").grid(row=0, column=0)
        self.title_entry.grid(row=0, column=1)

        tk.Label(root, text="Author").grid(row=1, column=0)
        self.author_entry.grid(row=1, column=1)

        tk.Label(root, text="ISBN").grid(row=2, column=0)
        self.isbn_entry.grid(row=2, column=1)

        tk.Label(root, text="Copies Purchased").grid(row=3, column=0)
        self.copies_purchased_entry.grid(row=3, column=1)

        tk.Label(root, text="Copies Available").grid(row=4, column=0)
        self.copies_available_entry.grid(row=4, column=1)

        tk.Label(root, text="Retail Price").grid(row=5, column=0)
        self.price_entry.grid(row=5, column=1)

        #Labels for add, update, and deleting books
        self.add_btn = tk.Button(root, text="Add Book", command=self.add_book)
        self.add_btn.grid(row=6, column=0)

        self.update_btn = tk.Button(root, text="Update Book", command=self.update_book)
        self.update_btn.grid(row=6, column=1)

        self.delete_btn = tk.Button(root, text="Delete Book", command=self.delete_book)
        self.delete_btn.grid(row=6, column=2)

        self.listbox = tk.Listbox(root)
        self.listbox.grid(row=7, column=0, columnspan=3)
        self.populate_books()

    def populate_books(self):
        """Displays books in the listbox
        """
        self.listbox.delete(0, tk.END) #clear list of books 
        for book in self.db.fetch_books(): #add book details
            self.listbox.insert(tk.END, f"{book['id']} | {book['title']} | {book['author']}")

    def add_book(self):
        """Adds book to the database
        """
        #Gets data
        title = self.title_entry.get()
        author = self.author_entry.get()
        isbn = self.isbn_entry.get()
        copies_purchased = self.copies_purchased_entry.get()
        copies_available = self.copies_available_entry.get()
        price = self.price_entry.get()

        #Validates using the validator class
        if Validator.validate_author(author) and Validator.validate_isbn(isbn) and \
           Validator.validate_copies(copies_purchased) and Validator.validate_copies(copies_available) and \
           Validator.validate_price(price):
            try:
                self.db.insert_book(title, author, isbn, int(copies_purchased), int(copies_available), float(price))
                messagebox.showinfo("Success", "Book added")
                
                self.clear_entries()
                self.populate_books() #refresh listbox
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add: {e}")
        else:
            messagebox.showerror("Error", "Invalid")

    def update_book(self):
        """Updates book details
        """
        selected_index = self.listbox.curselection()

        if not self.listbox.curselection():
            messagebox.showerror("Error", "None slected")
            return
        
        selected_item = self.listbox.get(selected_index[0])
        book_id = selected_item.split('|')[0].strip()
        book = self.db.fetch_books(book_id)

        #new window for updating 
        update_windows = tk.Toplevel(self.root)
        update_windows.title("Update Book")

        #Fields for updating book detail
        tk.Label(update_windows, text="Title").grid(row=0, column=0)
        title_entry = tk.Entry(update_windows)
        title_entry.grid(row=0, column=1)
        title_entry.insert(tk.END, book['title'])

        tk.Label(update_windows, text="Author").grid(row=1, column=0)
        author_entry = tk.Entry(update_windows)
        author_entry.grid(row=1, column=1)
        author_entry.insert(tk.END, book['author'])

        tk.Label(update_windows, text="Title").grid(row=0, column=0)
        title_entry = tk.Entry(update_windows)
        title_entry.grid(row=0, column=1)
        title_entry.insert(tk.END, book['title'])

        tk.Label(update_windows, text="ISBN").grid(row=3, column=0)
        isbn_entry = tk.Entry(update_windows)
        isbn_entry.grid(row=3, column=1)
        isbn_entry.insert(tk.END, book['isbn'])

        tk.Label(update_windows, text="Copies Purchased").grid(row=3, column=0)
        copies_purchased_entry = tk.Entry(update_windows)
        copies_purchased_entry.grid(row=3, column=1)
        copies_purchased_entry.insert(tk.END, book['copies_purchased'])

        tk.Label(update_windows, text="Copies Available").grid(row=4, column=0)
        copies_available_entry = tk.Entry(update_windows)
        copies_available_entry.grid(row=4, column=1)
        copies_available_entry.insert(tk.END, book['copies_available'])

        tk.Label(update_windows, text="Retail Price").grid(row=5, column=0)
        price_entry = tk.Entry(update_windows)
        price_entry.grid(row=5, column=1)
        price_entry.insert(tk.END, book['retail_price'])

        def final_update(): #saves updates
            updated_title = title_entry.get()
            updated_author = author_entry.get()
            updated_isbn = isbn_entry.get()
            updated_copies_purchased = copies_purchased_entry.get()
            updated_copies_available = copies_available_entry.get()
            updated_price = price_entry.get()

            #updates book in database
            self.db.update_book(book_id, updated_title, updated_author, updated_isbn,
                                updated_copies_purchased, updated_copies_available, updated_price)
            
            update_windows.destroy() # closes update window

            messagebox.showinfo("Success", "Book Updated")

            self.populate_books()
        tk.Button(update_windows, text="Submit", command=final_update).grid(row=6, column=0, columnspan=2)


    def delete_book(self):
        """Deletes select book 
        """
        selected_index = self.listbox.curselection()

        if not selected_index:
            messagebox.showerror("Error", "No book selected")
            return
        
        selected_item = self.listbox.get(selected_index[0])

        book_id = selected_item.split('|')[0].strip()

        self.db.remove_book(book_id)

        messagebox.showinfo("Success", "Book deleted")

        self.populate_books()
        


    def clear_entries(self):
        """Clears all the fields
        """
        self.title_entry.delete(0, tk.END)
        self.author_entry.delete(0, tk.END)
        self.isbn_entry.delete(0, tk.END)
        self.copies_purchased_entry.delete(0, tk.END)
        self.copies_available_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)


if __name__ == "__main__":
    root = tk.Tk()
    app = LibraryApp(root)
    root.mainloop()


