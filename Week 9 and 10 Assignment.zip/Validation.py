import re

class Validator:
    """
    Verifies all of the fields
    """
    @staticmethod
    def validate_author(author):
        """
        Validates characters for author
        """
        return bool(re.match(r'^[A-Za-z\s]+$', author)) #checks for characters in authors name only
    
    @staticmethod
    def validate_isbn(isbn):
        """
        validates length of character for isbn 
        """
        return isbn.isdigit() and len(isbn) == 13 #checks if isbn is a number and 13 characters
    
    @staticmethod
    def validate_copies(copies):
        """
        Validates that copies is a number
        """
        return copies.isdigit() # checks if copies purchased and available are a digit
    
    @staticmethod
    def validate_price(price):
        """
        validates price being a float above 0
        """
        try:
            return float(price) > 0 # price is a float above 0
        except ValueError:
            return False